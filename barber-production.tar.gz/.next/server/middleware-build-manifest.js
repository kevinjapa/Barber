globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/sL9_dzCwZIglBBDM9xUXJ/_buildManifest.js",
    "static/sL9_dzCwZIglBBDM9xUXJ/_ssgManifest.js",
    "static/sL9_dzCwZIglBBDM9xUXJ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/12aruqaur5huj.js",
    "static/chunks/3q5hirtwweuqh.js",
    "static/chunks/1j_9b-l0n6u-t.js",
    "static/chunks/turbopack-3tz67i07c_pdu.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
