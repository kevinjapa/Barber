module.exports=[78791,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reservar_page_actions_02lenha.js.map